#!/bin/sh
# تنظيف عند إزالة الموديول (يستدعيه Magisk)
rm -f /data/local/turbonet/99-turbonet.conf 2>/dev/null
exit 0
