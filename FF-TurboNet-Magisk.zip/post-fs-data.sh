#!/system/bin/sh
# FF TurboNet — يشتغل مبكرًا عند الإقلاع (قبل service.sh)
MODDIR=${0%/*}
# إزالة سجل قديم ليبدأ جديدًا كل إقلاع
rm -f "$MODDIR/turbonet.log" 2>/dev/null
exit 0
