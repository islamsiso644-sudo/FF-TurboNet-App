#!/system/bin/sh
# ═══════════════════════════════════════════════════════════
# FF TurboNet — Magisk Module
# يشتغل تلقائيًا بعد الإقلاع (late_start service) بصلاحيات روت.
# ⚠️ قانوني 100%: يعدّل إعدادات نظام الشبكة فقط (sysctl).
#    لا يلمس فري فاير أو أي لعبة — لا ملفات، لا ذاكرة، لا باكتات.
# ═══════════════════════════════════════════════════════════

MODDIR=${0%/*}
LOG="$MODDIR/turbonet.log"
echo "$(date) — FF TurboNet starting" > "$LOG"

# ── 1) ضبط بافرات UDP (أهم شيء لفري فاير — اللعبة تعمل بـ UDP) ──
SYSCTL="sysctl -w"

apply() {
    # $1 = المفتاح  $2 = القيمة
    $SYSCTL "$1=$2" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "  ✅ $1 = $2" >> "$LOG"
    else
        echo "  ⛔ $1 غير مدعوم بهذا الكيرنل (تم التخطي)" >> "$LOG"
    fi
}

echo "── UDP buffers ──" >> "$LOG"
apply net.core.rmem_max           16777216
apply net.core.wmem_max           16777216
apply net.core.rmem_default       1048576
apply net.core.wmem_default       1048576
apply net.ipv4.udp_mem            "8388608 12582912 16777216"
apply net.ipv4.udp_rmem_min       16384
apply net.ipv4.udp_wmem_min       16384

echo "── TCP buffers & speed ──" >> "$LOG"
apply net.core.netdev_max_backlog 5000
apply net.core.somaxconn          4096
apply net.ipv4.tcp_rmem           "4096 87380 16777216"
apply net.ipv4.tcp_wmem           "4096 65536 16777216"
apply net.ipv4.tcp_fastopen       3
apply net.ipv4.tcp_sack           1
apply net.ipv4.tcp_frto           2
apply net.ipv4.tcp_mtu_probing    1
apply net.ipv4.tcp_no_metrics_save 1

echo "── Keepalive (ثبات الاتصال — ضد قطع الجلسات) ──" >> "$LOG"
apply net.ipv4.tcp_keepalive_time   60
apply net.ipv4.tcp_keepalive_intvl  10
apply net.ipv4.tcp_keepalive_probes 5

# ── 2) حفظ الإعدادات داخل بارتيتشن الداتا (تبقى مرجعًا بعد إعادة التشغيل) ──
mkdir -p /data/local/turbonet 2>/dev/null
cat > /data/local/turbonet/99-turbonet.conf << 'EOF'
# FF TurboNet tuning — يُطبَّق عند الإقلاع من موديول Magisk
net.core.rmem_max=16777216
net.core.wmem_max=16777216
net.ipv4.udp_mem=8388608 12582912 16777216
net.ipv4.tcp_rmem=4096 87380 16777216
net.ipv4.tcp_wmem=4096 65536 16777216
net.ipv4.tcp_fastopen=3
net.ipv4.tcp_sack=1
net.ipv4.tcp_frto=2
net.ipv4.tcp_mtu_probing=1
net.ipv4.tcp_keepalive_time=60
net.ipv4.tcp_keepalive_intvl=10
net.ipv4.tcp_keepalive_probes=5
EOF
echo "── saved config to /data/local/turbonet/99-turbonet.conf ──" >> "$LOG"

# ── 3) إيقاف تطبيقات الخلفية الشهيرة المستهلكة (توفير RAM/CPU — لا يلمس الألعاب) ──
# ملاحظة: force-stop عند الإقلاع غير مجدٍ (تفتح من جديد)، نكتفي بمنع التشغيل التلقائي
# عبر "am" فقط للأ Apps المعروفة بالاستهلاك الشديد في الخلفية.
echo "── Background app notes ──" >> "$LOG"
echo "  (لن نوقف شيئًا هنا — استخدم زر 🎮 وضع اللعب في تطبيق FF TurboNet قبل اللعب)" >> "$LOG"

echo "$(date) — FF TurboNet done ✅" >> "$LOG"
