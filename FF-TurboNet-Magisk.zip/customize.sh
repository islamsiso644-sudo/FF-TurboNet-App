#!/bin/sh
# FF TurboNet — تعليمات تخصيص (يقرأها Magisk عند التثبيت)
# SKIPUNZIP=0 — نسمح بالفك العادي
SKIPUNZIP=0
